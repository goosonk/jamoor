class MobileNetV2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  features : __torch__.torch.nn.modules.container.___torch_mangle_202.Sequential
  classifier : __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.torchvision.models.mobilenetv2.MobileNetV2,
    x: Tensor) -> Tensor:
    classifier = self.classifier
    features = self.features
    x0 = torch.adaptive_avg_pool2d((features).forward(x, ), [1, 1])
    input = torch.flatten(x0, 1)
    _0 = (classifier).forward()
    return input
class InvertedResidual(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.torchvision.models.mobilenetv2.InvertedResidual,
    argument_1: Tensor) -> Tensor:
    conv = self.conv
    return (conv).forward(argument_1, )
