class FullMushroomVisionModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  backbone : __torch__.torchvision.models.mobilenetv2.MobileNetV2
  head : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.FullMushroomVisionModel,
    x: Tensor) -> Tensor:
    head = self.head
    backbone = self.backbone
    _0 = (head).forward((backbone).forward(x, ), )
    return torch.softmax(_0, 1)
